$(function(){
	$(".Contents").typed({
		strings: ['email &nbsp; : <a href="mailto:hello@aditkamath.com">hello@aditkamath.com</a> ^500 <br> twitter : <a href="https://twitter.com/aditkamath">@aditkamath</a> ^500 <br> github &nbsp;: <a href="https://github.com/aditkamath">@aditkamath</a>'],
		showCursor: false
	});
});